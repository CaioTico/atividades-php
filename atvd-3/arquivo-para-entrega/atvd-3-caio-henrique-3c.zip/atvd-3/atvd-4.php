<!DOCTYPE html>
<html>
<head>
    <title>Informações sobre o Time</title>
</head>
<body>
 
<?php
$nomeTime = "Milan";
$ano = 1995;
$anoTime = 1899;
$frase1 = "O Milan foi maior campeão Mundial da história.";
$frase2 = "Em $ano, ele recebeu o titulo de '1º Melhor Clube do Mundo'.";
 
echo "<h1>Informações sobre o Time</h1>";
echo "<p>Nome do time: $nomeTime</p>";
echo "<p>Ano: $anoTime</p>";
echo "<p> $frase1</p>";
echo "<p> $frase2</p>";
?>
 
</body>
</html>